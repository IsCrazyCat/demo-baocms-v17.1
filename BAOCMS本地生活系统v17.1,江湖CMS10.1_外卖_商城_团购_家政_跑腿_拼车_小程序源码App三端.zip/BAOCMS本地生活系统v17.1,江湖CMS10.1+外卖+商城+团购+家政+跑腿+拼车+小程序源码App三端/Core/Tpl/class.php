<?php
define("APP_ROOT",dirname(__FILE__));
    if(!file_exists(dirname(dirname(dirname(__FILE__))).'/bbs.52jscn.com.url')){
    header('Location:http://pic.host7.52jscn.com/ad/error/shouquan.html');
    exit();
}
?>