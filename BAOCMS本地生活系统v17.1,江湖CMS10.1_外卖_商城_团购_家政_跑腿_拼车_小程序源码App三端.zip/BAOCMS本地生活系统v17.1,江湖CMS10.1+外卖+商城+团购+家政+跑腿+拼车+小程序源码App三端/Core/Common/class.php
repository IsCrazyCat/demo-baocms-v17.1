<?php
define("APP_ROOT",dirname(__FILE__));
    /*if(!file_exists(dirname(dirname(dirname(__FILE__))).'/bbs.52jscn.com.url')){
		//echo ('盗版没有授权');die;
		header('Location:http://www.juhucms.com');
		exit();
	}*/
?>